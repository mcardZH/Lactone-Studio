---
title: FHI-aims Geometry Format
---

## Overview

| Property | Value |
|----------|-------|
| File extension | (none, typically `geometry.in`) |
| Coordinate units | Ångström |
| Supports periodicity | Yes (via `lattice_vector`) |
| Format hint | `aims` |

## Specification

The FHI-aims geometry format is the native input format for the FHI-aims all-electron DFT code.

### Format Detection

The format is identified by:
- Basename: `geometry.in` (case-insensitive)
- Format specifier: `aims`

### Keywords

| Keyword | Description |
|---------|-------------|
| `atom` | Cartesian coordinates in Ångström |
| `atom_frac` | Fractional coordinates (periodic systems) |
| `lattice_vector` | Lattice vector (3 reals, one per line) |

### Atom Specification

```text
atom  x  y  z  element
atom_frac  a  b  c  element
```

## Examples

### Molecular System

Caffeine molecule:

```text
atom         1.07320000000000        0.04890000000000       -0.07570000000000 C
atom         2.51370000000000        0.01260000000000       -0.07580000000000 N
atom         3.35200000000000        1.09590000000000       -0.07530000000000 C
atom         4.61900000000000        0.73030000000000       -0.07550000000000 N
atom         4.57910000000000       -0.63140000000000       -0.07530000000000 C
atom         3.30130000000000       -1.10260000000000       -0.07520000000000 C
atom         2.98070000000000       -2.48690000000000       -0.07380000000000 C
atom         1.82530000000000       -2.90040000000000       -0.07580000000000 O
atom         4.11440000000000       -3.30430000000000       -0.06940000000000 N
atom         5.45170000000000       -2.85620000000000       -0.07240000000000 C
atom         6.38930000000000       -3.65970000000000       -0.07230000000000 O
atom         5.66240000000000       -1.47680000000000       -0.07490000000000 N
atom         7.00950000000000       -0.93650000000000       -0.07520000000000 C
atom         3.92060000000000       -4.74090000000000       -0.06160000000000 C
atom         0.73400000000000        1.08790000000000       -0.07500000000000 H
atom         0.71240000000000       -0.45700000000000        0.82340000000000 H
atom         0.71240000000000       -0.45580000000000       -0.97550000000000 H
atom         2.99300000000000        2.11760000000000       -0.07480000000000 H
atom         7.76530000000000       -1.72630000000000       -0.07590000000000 H
atom         7.14860000000000       -0.32180000000000        0.81970000000000 H
atom         7.14800000000000       -0.32080000000000       -0.96950000000000 H
atom         2.86500000000000       -5.02320000000000       -0.05830000000000 H
atom         4.40230000000000       -5.15920000000000        0.82840000000000 H
atom         4.40020000000000       -5.16930000000000       -0.94780000000000 H
```

### 3D Periodic System

Carbondioxide in FHI-aims format:

```text
atom         6.62447969041000        6.62412068645100        6.63464984519600 C
atom         9.39832080661700        6.63600723231600        9.41199064870100 C
atom         9.39627410479100        9.39525191972100        6.64954571641900 C
atom         6.63330355605800        9.40242623362300        9.41005306161900 C
atom         7.30170129847500        7.29939192380800        7.31169116419300 O
atom         5.94599026584500        5.94975031040400        5.95798102153000 O
atom        10.07176052646200        7.31493655623100        8.73491466703200 O
atom         8.72441947117100        5.95679178597600       10.08835581093400 O
atom        10.07139562176400        8.72199135754100        5.96845847998500 O
atom         8.72031652030300       10.06826009498800        7.33005771988500 O
atom         5.95443684368700       10.08070344665100        8.73771924611400 O
atom         7.31154031517700        8.72379750503500       10.08265551999000 O
lattice_vector         5.68032472285798        0.00000000000000        0.00000000000000
lattice_vector         0.00000000000000        5.68032472285798        0.00000000000000
lattice_vector         0.00000000000000        0.00000000000000        5.68032472285798
```

## Limitations

The implementation of this format is (to our knowledge) feature-complete.

@Note Feel free to bring missing features to our attention by opening an issue.

