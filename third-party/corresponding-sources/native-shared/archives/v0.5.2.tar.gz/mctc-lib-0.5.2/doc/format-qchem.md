---
title: Q-Chem Molecule Format
---

## Overview

| Property | Value |
|----------|-------|
| File extension | `.qchem` |
| Coordinate units | Ångström |
| Supports periodicity | No |
| Supports charge/spin | Yes |
| Format hint | `qchem` |

## Specification

@Note Reference: [Q-Chem manual](https://manual.q-chem.com/5.1/sect-molinput.html)

The Q-Chem molecule format specifies molecular geometry within a `$molecule` block.

### Format Structure

```text
$molecule
 charge  multiplicity
 element  x  y  z
 element  x  y  z
 ...
$end
```

### Elements

Elements can be specified by:
- Element symbols (e.g., `C`, `H`, `O`)
- Atomic numbers (e.g., `6`, `1`, `8`)

## Example

Caffeine molecule:

```text
$molecule
 0  1
 C         1.07320000000000        0.04890000000000       -0.07570000000000
 N         2.51370000000000        0.01260000000000       -0.07580000000000
 C         3.35200000000000        1.09590000000000       -0.07530000000000
 N         4.61900000000000        0.73030000000000       -0.07550000000000
 C         4.57910000000000       -0.63140000000000       -0.07530000000000
 C         3.30130000000000       -1.10260000000000       -0.07520000000000
 C         2.98070000000000       -2.48690000000000       -0.07380000000000
 O         1.82530000000000       -2.90040000000000       -0.07580000000000
 N         4.11440000000000       -3.30430000000000       -0.06940000000000
 C         5.45170000000000       -2.85620000000000       -0.07240000000000
 O         6.38930000000000       -3.65970000000000       -0.07230000000000
 N         5.66240000000000       -1.47680000000000       -0.07490000000000
 C         7.00950000000000       -0.93650000000000       -0.07520000000000
 C         3.92060000000000       -4.74090000000000       -0.06160000000000
 H         0.73400000000000        1.08790000000000       -0.07500000000000
 H         0.71240000000000       -0.45700000000000        0.82340000000000
 H         0.71240000000000       -0.45580000000000       -0.97550000000000
 H         2.99300000000000        2.11760000000000       -0.07480000000000
 H         7.76530000000000       -1.72630000000000       -0.07590000000000
 H         7.14860000000000       -0.32180000000000        0.81970000000000
 H         7.14800000000000       -0.32080000000000       -0.96950000000000
 H         2.86500000000000       -5.02320000000000       -0.05830000000000
 H         4.40230000000000       -5.15920000000000        0.82840000000000
 H         4.40020000000000       -5.16930000000000       -0.94780000000000
$end
```

## Limitations

The following features are currently not supported:

- Coordinate units other than Ångström (Bohr option)

@Note Feel free to contribute support for missing features
      or bring missing features to our attention by opening an issue.

